---
type: note
subtype: object
status: active
layer: analytical_foundation
design_role: mechanism_definition
scope: chapter2_core
related_to:
  - A01_Extensive_Accumulation
  - A02_Intensive_Accumulation
  - N00_Mechanization_Analytical_References
  - R05_Frontier_of_Not_Becoming
  - R06_Regime_Gating_and_Diagnostic_Ladder
created: 2026-05-27
---

# A03: Transformation Elasticity and Two-Capital Capacity Composition

## Core Claim
The transformation elasticity $\theta^N$ is not an exogenous technical constant or an aggregate statistical coefficient. It emerges endogenously from the Double Choice of Technique as a **composition-weighted structural parameter** that maps capital accumulation to productive capacity growth. 

It is strictly conditioned by the infrastructural envelope ($K^{NRC}$), distributively modulated through the optimal mechanization choice ($K^{ME}$), and grounded in constant-reference prices to ensure stock-flow consistency. It serves exclusively as the analytical abstraction of **"not becoming"** (smooth reproduction limit) against which historical capacity utilization is measured.

---

## 1. Two-Capital Architecture & Capacity Identity
Productive capacity ($Y^p$) is the joint outcome of the extensive and intensive margins:
1. **Extensive Margin ($K^{NRC}$):** Defines the structural envelope $\Gamma(K^{NRC})$ and baseline capacity scale.
2. **Intensive Margin ($K^{ME}$):** Defines the tactical technique $q = K^{ME}/L$ and normal labor productivity $a^N = Y^p/L$.

Eliminating labor $L$ between $a^N$ and $q^*$ yields the **capacity composition identity**:
$$ Y^p = \frac{a^N(\omega, s)}{q^*(\omega, s)} K^{ME} + \Gamma(K^{NRC}) $$
where $s = K^{ME}/(K^{ME} + K^{NRC})$ is the mechanization composition share. This identity analytically decomposes capacity into the machinery-scaled productivity channel and the direct infrastructural envelope contribution.

---

## 2. Price Deflation, Stock-Flow Consistency & Composition Share
The composition share $s$ and capital growth rates cannot be constructed from nominal stocks or mixed-price aggregates. $K^{NRC}$ and $K^{ME}$ are priced using distinct capital goods deflators ($P^{NRC}_t, P^{ME}_t$), which exhibit different inflation dynamics and technological biases. To ensure dimensional homogeneity and accounting rigor, all capital stocks are expressed in **base-year $r$ reference prices**:

$$ K^{j}_t = \frac{K^{j, \text{nom}}_t}{P^{j}_t / P^{j}_r}, \quad j \in \{NRC, ME\} $$
where $P^{j}_r = 1$ by definition of the national accounts base year. This satisfies Basu's (2022) requirement that all ratios and shares entering analytical or empirical relations be dimensionless.

**Stock-Flow Accounting:**
Real capital stocks evolve via the perpetual inventory method (PIM):
$$ K^{j}_t = (1-\delta^j)K^{j}_{t-1} + i^{j}_t $$
where $i^{j}_t$ is real investment flow, and $\delta^j$ is type-specific depreciation. Growth rates are derived consistently from flows:
$$ g_{K^{j}, t} = \frac{i^{j}_t}{K^{j}_{t-1}} - \delta^j $$

**Composition Share in Constant Prices:**
$$ s_t = \frac{K^{ME}_t}{K^{NRC}_t + K^{ME}_t} $$
Because all $K^j_t$ are in base-year $r$ prices, $s_t$ is a **pure physical composition metric**. It isolates the structural shift toward machinery from nominal price effects. Changes in $s_t$ are driven by physical accumulation differentials ($g_{K^{ME}} \neq g_{K^{NRC}}$), not by relative price drift. This price decomposition ensures that the transformation elasticity $\theta^N$ captures real capacity mapping, not valuation artifacts.

---

## 3. Derivation of Marginal Capacity Payoffs
The transformation elasticity arises by differentiating the capacity identity with respect to each capital stock, holding regime parameters and distributive conditions fixed for the marginal derivation.

### 3.1 Machinery Payoff ($\theta^{ME}$)
From the machinery channel of the identity:
$$ \theta^{ME} \equiv \frac{\partial \ln Y^p}{\partial \ln K^{ME}} = \frac{a^N(\omega, s)}{q^*(\omega, s)} $$
Substituting the regime-conditioned mechanization frontier $a^N = \lambda_0^{[s]} + \lambda_1^{[s]} q^* + \lambda_2^{[s]} (q^*)^2$:
$$ \theta^{ME}(\omega, s) = \frac{\lambda_0^{[s]}}{q^*(\omega, s)} + \lambda_1^{[s]} + \lambda_2^{[s]} q^*(\omega, s) $$
**Analytical Meaning:** $\theta^{ME}$ is the direct capacity payoff of machinery accumulation. It is explicitly distributively conditioned because $q^*$ responds to $\omega$, and regime-dependent because $\lambda^{[s]}$ shifts with structural reorganization.

### 3.2 Infrastructure Payoff ($\theta^{NRC}$)
The infrastructural envelope $\Gamma(K^{NRC})$ is structurally determined and independent of $\omega$:
$$ \theta^{NRC} \equiv \frac{\partial \ln \Gamma(K^{NRC})}{\partial \ln K^{NRC}} $$
This represents the baseline, non-distributive capacity elasticity of the extensive margin. It is governed by long-run closure conditions and spatial-logistical architecture, not by tactical cost-minimization.

---

## 4. Emergence of the Aggregate Transformation Elasticity $\theta^N$
Total capital accumulation growth is composition-weighted and accounting-consistent:
$$ g_K^N = s \cdot g_{K^{ME}} + (1-s) \cdot g_{K^{NRC}} $$
Productive capacity growth follows from the marginal payoffs:
$$ g_{Y^p} = \theta^{NRC} \cdot (1-s) g_{K^{NRC}} + \theta^{ME}(\omega, s) \cdot s \cdot g_{K^{ME}} $$
The **aggregate transformation elasticity** is defined as the ratio of capacity growth to total capital growth:
$$ \theta^N(\omega, s) \equiv \frac{g_{Y^p}}{g_K^N} = \frac{\theta^{NRC}(1-s) g_{K^{NRC}} + \theta^{ME}(\omega, s) s g_{K^{ME}}}{(1-s) g_{K^{NRC}} + s g_{K^{ME}}} $$

**Consistency with Gap Formulation (H01):**
When accumulation is machinery-dominated ($g_{K^{ME}} \approx g_K^N$ and $s \to 1$), the aggregate elasticity simplifies to:
$$ \theta^N \approx \theta^{ME} = \frac{a^N}{q^*} = 1 + \frac{a^N - q^*}{q^*} \approx 1 + \frac{a^N - q^*}{g_K^N} $$
This recovers the analytical gap formulation used in `H01`, proving that $\theta^N$ and the productivity-mechanization gap are mathematically equivalent representations of the same structural object under different composition regimes.

---

## 5. Distributive Conditioning & Induced Innovation
Because $q^*(\omega, s)$ increases with distributive pressure ($\partial q^*/\partial \omega > 0$), $\theta^{ME}$ is dynamically modulated by class conflict:
$$ \frac{\partial \theta^{ME}}{\partial \omega} = \frac{\partial \theta^{ME}}{\partial q^*} \cdot \frac{\partial q^*}{\partial \omega} $$
Given $\lambda_2^{[s]} < 0$ (concave frontier), $\theta^{ME}$ typically exhibits diminishing marginal capacity payoff as mechanization intensifies. Higher $\omega$ pushes $q^*$ rightward along the frontier, altering the structural efficiency of accumulation. This is the analytical core of **induced innovation**: distribution does not shift the production function; it shifts the optimal technique, which in turn alters the transformation elasticity $\theta^N$.

---

## 6. Ontological Status & Analytical Function
1. **Abstraction of "Not Becoming":** $\theta^N(\omega, s)$ is a smooth-reproduction benchmark. It defines the maximum structural efficiency of the accumulation process under idealized coordination and fixed regime parameters $\lambda^{[s]}$.
2. **Historical "Becoming":** Real capacity formation is decentralized, internally divided, and crisis-prone. The actual transformation ratio $\theta_t$ systematically deviates from $\theta^N$ due to Okishio's market anarchy, Vidal's internal firm division, and utilization gaps ($\mu_t \neq 1$).
3. **Regime Dependence:** $\theta^N$ is not globally stable. It jumps discretely when the extensive margin undergoes structural reorganization ($s \to s'$), shifting all $\lambda_i^{[s]}$ and recalibrating both $\theta^{NRC}$ and $\theta^{ME}$. This justifies gating empirical threshold transitions on extensive-margin closure conditions (`R06`).
4. **Empirical Bridge:** In the Basu-compliant cointegration framework, $\theta^N$ corresponds to the systematic part of the capacity reconstruction vector. The deviation $\tilde{\mu}_t = \ln(Y_t/Y_r) - \ln \hat{Y}^p_t$ captures the ontological distance between the smooth-reproduction abstraction and historical reality.

---

## Locked Formulation
The transformation elasticity $\theta^N$ emerges endogenously from the Double Choice of Technique as a composition-weighted structural parameter. It aggregates the baseline capacity payoff of infrastructure ($\theta^{NRC}$) and the distributively conditioned payoff of machinery ($\theta^{ME}$), mapping total capital accumulation to productive capacity growth. Induced innovation operates through $\theta^{ME}$ by shifting the optimal mechanization rate $q^*(\omega)$ along a regime-conditioned frontier. $\theta^N$ is strictly an analytical abstraction of "not becoming" (smooth reproduction); historical deviations from it are the structural fingerprints of capitalist "becoming," measured via the utilization gap and gated by extensive-margin regime transitions. All capital stocks, composition shares, and growth rates are grounded in constant-reference prices to ensure dimensional homogeneity and stock-flow accounting consistency.