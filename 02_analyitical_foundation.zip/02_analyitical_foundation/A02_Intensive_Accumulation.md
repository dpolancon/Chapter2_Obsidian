---
type: note
subtype: object
status: active
layer: analytical_foundation
design_role: mechanism_definition
scope: chapter2_core
related_to:
  - N00_Mechanization_Analytical_References
  - H03_Double_Choice_of_Technique
  - N04_Extensive_Margin_and_Structural_Envelope
  - R05_Frontier_of_Not_Becoming
  - Okishio_Vidal_Transformation_Elasticity
created: 2026-05-27
---

# A02 Intensive Accumulation: Choice of Technique and Mechanization Optimization

## Core Claim
The firm's optimization over mechanization is not a unified, globally coherent profit-maximization problem. It is a **conditional cost-surplus maximization** along a technological frontier strictly conditioned by the structural envelope ($K^{NRC}$). 

This optimization yields a normal rate of labor productivity and serves exclusively as the analytical abstraction of **"not becoming"** (smooth reproduction limit). Historical deviations from this limit capture Okishio's market anarchy, Vidal's internal firm division, and utilization gaps.

---

## 1. Problem Statement & Objective Function
Given a fixed infrastructural envelope, the tactical margin of accumulation chooses the mechanization rate $q = K^{ME}/L$ to optimize the net productivity surplus:
$$ \max_{q} \ c(q) = a - q(1-\omega) $$
where:
- $a = Y/L$ is labor productivity
- $1-\omega$ is the capital cost share (proxy for the unit cost of mechanization net of wage pressure)
- $q(1-\omega)$ represents the effective cost of deploying machinery per worker

The objective captures the Marxian/induced-innovation logic: mechanization is pursued to expand productivity ($a$), but is constrained by the distributive cost of capital intensity $(1-\omega)$.

---

## 2. Technological Frontier & Infrastructure Conditioning
The choice is bounded by a mechanization productive frontier that is **explicitly conditioned** on the extensive margin:
$$ a = \Phi(q; K^{NRC}) = \lambda_0(K^{NRC}) + \lambda_1(K^{NRC})q + \lambda_2(K^{NRC})q^2 $$

**Properties:**
- $\lambda_0(K^{NRC}) > 0$: Base productivity level rises with better infrastructure
- $\lambda_1(K^{NRC}) > 0$: Linear mechanization payoff increases with plant scale and logistical efficiency
- $\lambda_2(K^{NRC}) < 0$: Diminishing marginal productivity of mechanization (concavity condition)
- $\frac{\partial \lambda_i}{\partial \omega} = 0$: Frontier parameters are structurally determined, not distributively shifted

**Analytical Role of $K^{NRC}$:** Infrastructure does not enter the objective function as an optimization variable or an interactive term with $\omega$. It strictly shifts the technological frontier, altering the ceiling, marginal payoff, and curvature of the mechanization choice.

---

## 3. First-Order Condition & Optimal Mechanization
Substituting the frontier into the objective yields the unconstrained tactical problem:
$$ c(q) = \lambda_0(K^{NRC}) + \left[ \lambda_1(K^{NRC}) - (1-\omega) \right]q + \lambda_2(K^{NRC})q^2 $$

**FOC:** Differentiating with respect to $q$ and setting to zero:
$$ \frac{dc}{dq} = \lambda_1(K^{NRC}) - 1 + \omega + 2\lambda_2(K^{NRC})q^* = 0 $$

**Optimal Mechanization Rate:**
$$ q^*(\omega, K^{NRC}) = \frac{1 - \lambda_1(K^{NRC}) - \omega}{2\lambda_2(K^{NRC})} $$

**Comparative Statics (Induced Innovation):**
$$ \frac{\partial q^*}{\partial \omega} = -\frac{1}{2\lambda_2(K^{NRC})} > 0 \quad \text{(since } \lambda_2 < 0\text{)} $$
Higher distributive pressure mechanically shifts the optimal technique toward greater mechanization. The cost-minimizing response to wage bargaining is the expansion of $q^*$ along the frontier.

**Second-Order Condition:** $c''(q) = 2\lambda_2(K^{NRC}) < 0$ ensures an interior, stable maximum.

---

## 4. Normal Labor Productivity (Smooth Reproduction Benchmark)
Substituting $q^*$ back into the frontier yields the **normal rate of labor productivity**:
$$ a^N(\omega, K^{NRC}) = \lambda_0(K^{NRC}) + \lambda_1(K^{NRC})q^* + \lambda_2(K^{NRC})(q^*)^2 $$

**Interpretation:**
- $a^N$ is the frictionless productivity ceiling achievable under the current wage share and infrastructural envelope.
- It is a **structural limit**, not a historical average.
- Changes in $\omega$ shift the optimal technique along the frontier, altering $a^N$ without changing the frontier itself.
- Changes in $K^{NRC}$ shift the entire frontier outward, raising the baseline capacity for tactical optimization.

---

## 5. Ontological Status: The Optimization as "Not Becoming"
Per the Okishio-Vidal articulation and `R05`, this optimization problem **does not assume** a representative, unified firm solving a global profit-maximization problem. Instead:

1. **Abstraction of "Not Becoming":** $q^*(\omega, K^{NRC})$ and $a^N(\omega, K^{NRC})$ represent the smooth reproduction benchmark under idealized coordination. They define the geometric boundary of what is technically and distributively possible.
2. **Historical "Becoming":** Real accumulation is decentralized, internally divided, and crisis-prone. Firms rarely operate exactly at $q^*$. The actual mechanization rate $q_t$ and productivity $a_t$ deviate systematically due to:
   - Capitalist market anarchy (Okishio)
   - Contested capacity conventions and internal firm division (Vidal)
   - Financial constraints and external wedges
3. **Analytical Function:** The optimization provides the necessary theoretical limit against which historical contradiction is measured. The gap $a_t - a^N(\omega, K^{NRC})$ and the resulting utilization deviation $\mu_t \neq 1$ are the empirical fingerprints of capitalist "becoming."

---

## Locked Formulation
The tactical choice of technique is formalized as a cost-surplus maximization over the mechanization rate, subject to a technological frontier strictly conditioned by the structural envelope ($K^{NRC}$). The first-order condition yields an optimal mechanization rate that responds positively to distributive pressure, capturing the induced innovation mechanism. The resulting normal labor productivity ($a^N$) is not a behavioral prediction but an analytical abstraction of "not becoming" (smooth reproduction). It serves exclusively as the theoretical benchmark against which the contradictory reality of decentralized accumulation, internal firm division, and utilization gaps are measured. Infrastructure conditions the frontier; distribution shifts the optimal technique along it. Neither interacts across margins.