---
type: note
status: active
layer: analytical_foundation
design_role: mechanism_definition
scope: chapter2_core
related_to:
  - N00_Mechanization_Analytical_References
  - N04_Composition_of_Accumulation_and_Transformation
  - N05_Normal_Reproduction_Closure
created: 2026-05-05
updated: 2026-05-27
---

# Mechanization problem

## Core claim
Mechanization determines how accumulation is transformed into labor productivity growth. It is modeled as an induced, cost-minimizing choice under distributive and external constraints, grounded in a Marxian reinterpretation of technical change.

The mechanism is defined independently of equilibrium or optimality assumptions, but explicitly dependent on closure conditions.

---

## 1. Mechanization variable
Let:
$$ q_t = \Delta \ln Q_t, \quad Q_t = \frac{K^M_t}{L_t} $$
Mechanization is driven by machinery accumulation. 
**Grounding:** Cajas (2024) provides the micro-foundation of mechanization as an optimization problem where productivity depends nonlinearly on mechanization.

---

## 2. Capital Productivity Identity
Capital productivity is not autonomous. It reflects the balance between labor productivity and mechanization:
$$ \frac{Y}{K} = \frac{Y/L}{K/L} $$
**Grounding:** Kaldor (1957) links productivity to capital deepening. This identity ensures that capital productivity is endogenous to the mechanization choice.

---

## 3. Mechanization choice (Induced Innovation)
Mechanization responds to distributive and structural conditions:
$$ q_t = q(\omega_t, E_t) $$
- $\omega_t \to$ wage share (distribution)
- $E_t \to$ external constraint (foreign exchange/import dependence)

**Grounding:** 
- Marx (Vol. I) & Cajas (2024): Mechanization as a response to wage pressure and a labor-disciplining device.
- Kennedy (1964), Duménil & Lévy: Technical change as a cost-minimizing choice under a technological frontier.
- Prebisch (1950), Thirlwall (1979), Kaldor (1959): External constraint on accumulation. In the periphery, mechanization depends on imported machinery, so accumulation $\neq$ mechanization.

---

## 4. Normal accumulation benchmark
All transformation is evaluated relative to the normal reproduction path:
$$ g^K_{N,t} = \chi^N_t r^N_t - \delta $$
with:
- $r^N_t \to$ normal profit rate
- $\chi^N_t \to$ normal reinvestment ratio
- $\mu_t = 1 \to$ full utilization

**Grounding:** Basu (2022, 2024) defines normal profitability and accumulation, providing closure conditions (strong labor, weak labor, labor surplus). Accumulation depends on profitability and recapitalization, not mechanically tied to savings.

---

## 5. Machinery-specific transformation elasticity
Define the transformation gap $b_t = a_t - q_t$. The machinery-specific transformation elasticity is:
$$ \theta^M_t = 1 + \frac{b_t}{g^K_{N,t}} $$
**Grounding:** This measures the capacity payoff of accumulation. It depends on two corridors (normal reproduction and peripheral constraint).

---

## 6. Okishio Reinterpretation (Closure-Dependence)
The Okishio theorem is reinterpreted not as a universal law, but as a closure-dependent mechanism. 
**Grounding:** Regulation theory (Aglietta, Boyer) and Basu (2024) show that transformation elasticity is not globally stable. Regimes define corridor dominance (e.g., Fordism vs. post-Fordism, or center vs. periphery).

---

## Locked formulation
Mechanization determines labor productivity growth through a function depending on machinery accumulation and infrastructure. The transformation elasticity is defined as the relation between productivity gains and the normal accumulation path under conditions of smooth reproduction. It is a cost-minimizing choice induced by wage pressure and external constraints, and its stability is regime-dependent rather than universally guaranteed by Okishio's theorem.