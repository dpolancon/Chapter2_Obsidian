---
type: note
subtype: object
status: active
layer: analytical_foundation
design_role: mechanism_definition
scope: chapter2_core
related_to:
  - N00_Mechanization_Analytical_References
  - H01_Cajas_to_Transformation_Elasticity
  - H03_Double_Choice_of_Technique
  - N05_Normal_Reproduction_Closure
  - R05_Frontier_of_Not_Becoming
created: 2026-05-27
---

# N04: Extensive Margin and Structural Envelope ($K^{NRC}$)

## Core Claim
Non-Residential Construction/Infrastructure ($K^{NRC}$) defines the **extensive margin** of accumulation. It is not a tactical optimization variable but a structural planning decision governed by long-run reproduction conditions, financial/institutional closure, and expected trend demand. 

By structural design, $K^{NRC}$ evolves independently of short-run distributive conflict ($\omega$) and serves exclusively as the fixed envelope that conditions the parameters of the mechanization productive frontier.

---

## 1. Definition & Ontological Role
$K^{NRC}$ represents the physical plant capacity, logistical networks, and foundational spatial layout of production. 
- **Extensive Margin:** Sets the maximum structural scale of the economy.
- **Ontological Status:** Represents the analytical abstraction of **"not becoming"** (smooth reproduction limit). It defines the geometric boundary within which tactical technique choice occurs.
- **Analytical Function:** Provides the structural envelope $\Gamma(K^{NRC})$ that maps infrastructure stock to potential productive capacity.

---

## 2. Temporal & Structural Properties
Unlike machinery, $K^{NRC}$ exhibits distinct temporal and physical characteristics:
- **Lumpiness:** Committed in discrete, multi-year projects. Cannot be marginally adjusted.
- **Irreversibility & Sunk Costs:** Once built, infrastructure becomes a fixed constraint. Quick liquidation or tactical repurposing is economically and physically constrained.
- **Long Gestation:** Planning, financing, and construction span multiple business cycles (5–15 years).
- **Spatial Fixity:** Geographically anchored, shaping regional productivity and logistical efficiency.

*Reconciliation with "Normal" Accumulation:* Lumpiness refers to the micro/project reality. The "normal accumulation corridor" is a macro-planning abstraction that defines the institutional and financial center of gravity for these discrete commitments when aggregated and filtered over long horizons.

---

## 3. Decision Rule: Normal Accumulation Corridor
$K^{NRC}$ accumulation follows a reproduction closure condition rather than a marginal cost-minimization rule. Following Basu's reproduction schemas and Kaldor's structural accumulation logic, it evolves along a normal corridor:

$$ g_{K^{NRC}, t}^N = \chi^N r^N_t - \delta $$
$$ K^{NRC}_t = K^{NRC}_{t-1} \cdot (1 + g_{K^{NRC}, t}^N) $$

Where:
- $g_{K^{NRC}}^N$: Planned growth rate of plant capacity
- $\chi^N$: Institutionally/financially determined reinvestment ratio into fixed infrastructure (credit closure, state policy, retained earnings conventions)
- $r^N_t$: Normal profit rate anchored to long-run structural conditions (institutional wage-price norms, monetary policy, sectoral competition)
- $\delta$: Physical depreciation rate of infrastructure

**Analytical Meaning:** This rule defines the structural capacity to commit to lumpy projects under idealized coordination. It strips away cyclical noise to reveal the institutional profitability and financial constraints that gate long-run capacity planning.

---

## 4. Independence from Distributive Conflict ($\omega$)
By structural design, $\frac{\partial K^{NRC}}{\partial \omega} = 0$. Three analytical justifications:
1. **Time-Horizon Mismatch:** $K^{NRC}$ planning operates on multi-decade horizons. Short-run fluctuations in $\omega_t$ are filtered out as cyclical noise in long-run capacity forecasts.
2. **Irreversibility:** Infrastructure cannot be tactically adjusted to wage bargaining. A wage settlement does not suddenly make a half-built factory viable or scrap a logistics hub.
3. **Financial/Institutional Gating:** Long-run plant capacity is mediated by credit availability, interest rate structures, and state infrastructure policy. These are institutional variables that operate independently of current-period cost conditions.

Thus, $K^{NRC}$ is determined by **structural closure**, not by distributive parameters.

---

## 5. Conditioning of the Intensive Margin
Although $K^{NRC}$ does not interact with $\omega$, it **strictly conditions** the tactical choice of technique. The parameters of the mechanization productive frontier are explicit functions of the structural envelope:

$$ a = \lambda_0(K^{NRC}) + \lambda_1(K^{NRC}) q + \lambda_2(K^{NRC}) q^2 $$

Where:
- $\lambda_0(K^{NRC}) > 0$: Base productivity level rises with better infrastructure
- $\lambda_1(K^{NRC}) > 0$: Linear mechanization payoff increases with plant scale and logistical efficiency
- $\lambda_2(K^{NRC}) < 0$: Curvature/diminishing returns parameter shifts with spatial and technological constraints of the plant

**Analytical Mechanism:** $K^{NRC}$ does not appear in the cost-minimization FOC for $q^*$. Instead, it shifts the *frontier itself*, altering the marginal productivity of machinery and the optimal technique $q^*(\omega, K^{NRC})$. This cleanly separates the extensive margin (structural planning) from the intensive margin (distributive-induced innovation).

---

## 6. Regime Shifts & Historical Deviations
The normal accumulation corridor is an analytical benchmark, not a historical average. Real-world $K^{NRC}$ trajectories deviate due to:
- Credit cycles and financialization shifts
- State-led infrastructure pushes or austerity
- Technological paradigm changes (e.g., digital logistics, green transition)

These deviations manifest as **low-frequency regime shifts** in the structural envelope, gating discrete breaks in the mechanization frontier parameters $\lambda_i(K^{NRC})$. They are not marginal adjustments but structural reorganizations of the extensive margin.

---

## Locked Formulation
$K^{NRC}$ defines the extensive margin of accumulation as a structural envelope governed by long-run reproduction conditions, financial/institutional closure, and expected trend demand. It evolves independently of short-run distributive conflict due to lumpiness, irreversibility, and multi-year planning horizons. Its analytical role is not to interact with tactical optimization, but to strictly condition the parameters of the mechanization productive frontier. Historical deviations from the normal accumulation corridor manifest as low-frequency regime shifts, providing the geometric and theoretical boundary against which the reality of capitalist accumulation is measured.